#!/bin/sh

doas su  ff -c  "firefox -p"