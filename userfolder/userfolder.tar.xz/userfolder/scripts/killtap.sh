#!/bin/sh

rm /tmp/tap_kill
ifconfig | grep tap | awk '{print $1}' | grep tap >> /tmp/tap_kill

for i in $(sed -e 's|:||g' /tmp/tap_kill); do

    doas       ifconfig $i destroy

      done