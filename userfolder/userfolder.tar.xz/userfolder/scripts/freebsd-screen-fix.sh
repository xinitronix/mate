```sh
#!/bin/sh
# FreeBSD: fix GNU Screen colors and gh OSC 11 artifacts.
# Run as the normal user, NOT as root.

set -eu

if [ "$(id -u)" -eq 0 ]; then
    echo "Run this script as your normal user, not root."
    exit 1
fi

for cmd in infocmp tic screen zsh; do
    if ! command -v "$cmd" >/dev/null 2>&1; then
        echo "Missing command: $cmd"
        exit 1
    fi
done

ZSHRC="$HOME/.zshrc"
SCREENRC="$HOME/.screenrc"
TERMINFO_DIR="$HOME/.terminfo"
SRC_DIR="$HOME/.terminfo-src"
SRC="$SRC_DIR/screen-256color.src"
TMP="$SRC_DIR/screen-256color.tmp"

mkdir -p "$TERMINFO_DIR" "$SRC_DIR"

backup_file() {
    file="$1"
    if [ -f "$file" ]; then
        cp -p "$file" "$file.bak.$(date +%Y%m%d-%H%M%S)"
        echo "Backup created: $file.bak.*"
    fi
}

# 1. Generate a 256-color terminfo entry based on xterm-256color.
if ! infocmp -1 xterm-256color > "$SRC"; then
    echo "Cannot find terminfo entry: xterm-256color"
    exit 1
fi

if ! grep -q '^xterm-256color|' "$SRC"; then
    echo "Unexpected infocmp output; refusing to modify it."
    exit 1
fi

sed 's/^xterm-256color|/screen-256color|/' "$SRC" > "$TMP"

if ! grep -q '^screen-256color|' "$TMP"; then
    echo "Could not generate screen-256color source."
    exit 1
fi

mv "$TMP" "$SRC"
tic -x -o "$TERMINFO_DIR" "$SRC"

COLORS=$(TERMINFO="$TERMINFO_DIR" \
    tput -T screen-256color colors)

if [ "$COLORS" -lt 256 ]; then
    echo "Error: screen-256color reports only $COLORS colors."
    exit 1
fi

echo "Created screen-256color terminfo: $COLORS colors"

# 2. Configure ~/.zshrc.
touch "$ZSHRC"

if ! grep -q '# BEGIN screen-256color fix' "$ZSHRC"; then
    backup_file "$ZSHRC"

    cat >> "$ZSHRC" <<'EOF'

# BEGIN screen-256color fix
# Use the custom 256-color entry only inside GNU Screen.
if [[ -n "$STY" ]]; then
    export TERMINFO="$HOME/.terminfo"
    export TERM=screen-256color
fi
# END screen-256color fix
EOF
    echo "Updated $ZSHRC"
else
    echo "Screen fix already exists in $ZSHRC"
fi

# 3. Configure ~/.screenrc.
touch "$SCREENRC"

if ! grep -Eq '^[[:space:]]*term[[:space:]]+screen-256color([[:space:]]|$)' "$SCREENRC"; then
    backup_file "$SCREENRC"
    printf '\n# Use 256-color terminal in Screen\nterm screen-256color\n' >> "$SCREENRC"
    echo "Updated $SCREENRC"
else
    echo "Screen terminal setting already exists."
fi

# 4. Verify the terminfo entry.
echo
echo "=== Verification ==="
echo "TERMINFO=$TERMINFO_DIR"
echo "screen-256color colors: $COLORS"
echo
echo "Next steps:"
echo "1. Start a new Screen session."
echo "2. Run: echo \"TERM=\$TERM\""
echo "3. Run: tput colors"
echo "4. Run: gh --version"
echo
echo "Expected inside Screen: TERM=screen-256color, colors=256."
echo "The custom terminfo entry is based on xterm-256color."
```