#!/bin/sh
URL=$(zenity --title="youtube"  --entry --text="Введите url")

if [ -z "$URL" ]
then
     echo "не введен url"
     exit
fi

ssh pi@192.168.8.45 sudo systemctl start    youtubeUnblock
ssh pi@192.168.8.45  rm yt.mp4
ssh pi@192.168.8.45 killall -9 yt-dlp 
ssh pi@192.168.8.45 killall -9 ffmpeg
ssh pi@192.168.8.45 sudo systemctl restart    youtubeUnblock
ssh pi@192.168.8.45 ./yt.sh $URL &
sleep 40 
curl -X POST -H "Content-Type: application/json" -d '{"jsonrpc":"2.0","id":1,"method":"Player.Open","params":{"item":{"file":"yt.mp4"}}}'  http://192.168.8.45:8081/jsonrpc