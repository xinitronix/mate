#!/bin/sh
DIR=$(dirname "$(realpath $0)")
if [ -z "$1" ]
then
     echo "не папка профиля firefox"
     exit
fi

    for i in $(cat $DIR/default  ); do

            rm -R $1/storage/default/$i 

done