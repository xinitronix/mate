#!/bin/sh
if [ -z "$1" ]
then
     echo "не введен мост"
     exit
fi

sshpass -p "639639" scp pi@192.168.8.45:/etc/tor/torrc /tmp/torrc
gsed -i '$d'   /tmp/torrc
echo  'Bridge' "$1" >> /tmp/torrc
sshpass -p "639639" scp /tmp/torrc root@192.168.8.45:/etc/tor/torrc
sshpass -p 639639 ssh pi@192.168.8.45 "killall -9 tor"
sshpass -p 639639 ssh pi@192.168.8.45 "tor"
sleep 6
sshpass -p 639639 ssh pi@192.168.8.45 "killall -9 tor"
sshpass -p 639639 ssh pi@192.168.8.45 "tor"