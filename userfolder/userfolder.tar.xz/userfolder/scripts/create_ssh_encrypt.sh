#!/bin/sh

if [ -z "$1" ]
then
     echo "не введен пароль для ssh enc"
     exit
fi

  for i in $(ls); do

cat  $i  | while read line
   do
      
 echo " echo '"$line"' >> $i"  >>  $i.sh
   done

 done 
cat *.sh > ssh.sh
cat ssh.sh | openssl enc -base64  -aes-256-cbc -iter 8 -pass pass:$1