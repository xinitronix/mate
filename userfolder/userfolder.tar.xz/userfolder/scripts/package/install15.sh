#!/bin/sh

if test "$(id -u)" -ne 0; then
	printf "%s must be run as root\n" "${0##*/}"
	exit 1
fi

ls /ntfs-2TB/All15 > /tmp/pkg15

 for i in $(cat /tmp/pkg15); do

           pkg add  /ntfs-2TB/All15/$i 

      done







