#!/bin/sh
#скрипт берет пакеты из All15 исключая пакеты нацинающийся на FreeBSD , затем 
#проверяет пакеты на наличие новых версий из репотизария FreeBSD 
rm /tmp/old_pkg15
rm /tmp/old_pkg15_without_ver 


( cd /ntfs-2TB/All15 && ls | grep -v '^FreeBSD' | sed 's/\.pkg$//'  ) >> /tmp/old_pkg15
( cd ~/2TB/All15 && ls | grep -v '^FreeBSD' | sed 's/\.pkg$//' | sed 's/-[0-9].*$//' ) >> /tmp/old_pkg15_without_ver 





rm /tmp/new_pkg15

for i in $(cat /tmp/old_pkg15_without_ver ); do

         pkg search -r FreeBSD "$i" | awk '{print $1}' | grep -E "^$i-[0-9]"   >> /tmp/new_pkg15

      done


diff /tmp/old_pkg15 /tmp/new_pkg15 -u  | grep -v '^@@.*@@$' | grep "+" | sed -e 's/^.//' | sed '1d' | sed '1d'  | grep -Ev 'nvidia-(driver|drm|kmod)' | sed 's/-[0-9][^-]*$//'   > /tmp/update_pkg15
echo 'nvidia-driver' >> /tmp/update_pkg15
echo 'nvidia-drm' >> /tmp/update_pkg15
echo 'nvidia-kmod' >> /tmp/update_pkg15
cat /tmp/update_pkg15

cd /ntfs-2TB/All15/ 

       while IFS= read -r i; do
  ls /ntfs-2TB/All15/ \
  | grep -E "^${i}-[0-9]+\.[0-9].*\.pkg$" \
  | xargs -r doas rm --
done < /tmp/update_pkg15
      