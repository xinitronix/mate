#!/bin/sh

line=$(uname -r | grep 16)

upload () {
doas pkg repo /ntfs-2TB/All16

ncftpput  -R -z -r 10 -v -u "pi" -p     "639639"     192.168.8.45             /home/pi/      /ntfs-2TB/All16


sshpass -p 639639 ssh pi@192.168.8.45 'chmod -R 777 /home/pi/All16'
}

if [ -z "$line" ]
then
     echo "\$var Пустая"
     echo "неправильная  версия FreeBSD"
else
   upload
fi
