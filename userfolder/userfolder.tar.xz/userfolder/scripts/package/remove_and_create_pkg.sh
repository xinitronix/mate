#!/bin/sh

if test "$(id -u)" -ne 0; then
	printf "%s must be run as root\n" "${0##*/}"
	exit 1
fi

if [ -z "$1" ]
then
     echo "введите название пакета ,которое надо обновить"
     exit
fi

PKG=$(ls 2TB/All15 | grep $1)

rm $HOME/2TB/All15/$PKG
sshpass -p 639639 ssh pi@192.168.8.45 "rm ~/All15/$PKG"
cd $HOME/2TB/All15/
pkg create $1
cd -
pkg repo /ntfs-2TB/All15

ncftpput  -R -z -r 10 -v -u "pi" -p     "639639"     192.168.8.45             /home/pi/      /ntfs-2TB/All15
ncftpput     -z -r 10 -v -u "pi" -p     "639639"     192.168.8.45             /home/pi/All15   /ntfs-2TB/All15/packagesite.txz
ncftpput     -z -r 10 -v -u "pi" -p     "639639"     192.168.8.45             /home/pi/All15   /ntfs-2TB/All15/meta.txz
ncftpput     -z -r 10 -v -u "pi" -p     "639639"     192.168.8.45             /home/pi/All15        /ntfs-2TB/All15/packagesite.txz
sshpass -p 639639 ssh pi@192.168.8.45 'chmod -R 777 /home/pi/All15'

