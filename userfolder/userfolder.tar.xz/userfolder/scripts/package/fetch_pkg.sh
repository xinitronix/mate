#!/bin/sh

cd /ntfs-2TB/All15/

 for i in `cat /tmp/update_pkg15` ; do 
    
  doas pkg fetch -r FreeBSD -o /ntfs-2TB/All15/ -y $i
  

done


cd /ntfs-2TB/All15/All/Hashed || exit 1

for f in *.pkg; do
  new=${f%%~*.pkg}.pkg
  [ "$f" = "$new" ] || doas mv "$f" "$new"
done

doas rm -r /ntfs-2TB/All15/All