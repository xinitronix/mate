#!/bin/sh


if test "$(id -u)" -ne 0; then
	printf "%s must be run as root\n" "${0##*/}"
	exit 1
fi

 for i in `cat /tmp/pkg_upgrade.txt` ; do 
    
  rm /ntfs-2TB/All/$i-*
  

done