
#!/bin/sh

# ============================================================
# Автоматическое обслуживание репозитория FreeBSD 16
# Репозиторий: /ntfs-2TB/All16
# Некорректные и резервные пакеты: /ntfs-2TB/InvalidPackages
# ============================================================

set -eu

REPO="/ntfs-2TB/All16"
QUARANTINE="/ntfs-2TB/InvalidPackages"

# ---------- Проверки ----------

if [ "$(id -u)" -ne 0 ]; then
    echo "ОШИБКА: запусти скрипт от root:"
    echo "doas sh $0"
    exit 1
fi

for cmd in pkg bsdtar jq find; do
    if ! command -v "$cmd" >/dev/null 2>&1; then
        echo "ОШИБКА: не найдена команда $cmd"
        exit 1
    fi
done

if [ ! -d "$REPO" ]; then
    echo "ОШИБКА: каталог $REPO не существует"
    exit 1
fi

if [ "$REPO" = "$QUARANTINE" ]; then
    echo "ОШИБКА: каталог репозитория совпадает с карантином"
    exit 1
fi

mkdir -p "$QUARANTINE"

echo "=========================================="
echo " ОБСЛУЖИВАНИЕ РЕПОЗИТОРИЯ FREEBSD 16"
echo "=========================================="
echo "Репозиторий: $REPO"
echo "Карантин:    $QUARANTINE"
echo

# ---------- Перемещение файлов ----------

move_aside()
{
    src="$1"
    relative="$2"

    dest="$QUARANTINE/$relative"
    parent=$(dirname "$dest")

    mkdir -p "$parent"

    original="$dest"
    n=1

    while [ -e "$dest" ] || [ -L "$dest" ]; do
        dest="${original}.duplicate${n}"
        n=$((n + 1))
    done

    mv "$src" "$dest"

    echo "[ПЕРЕМЕЩЁН] $src"
    echo "           -> $dest"
}

# ---------- Удаление вложенных пакетов ----------

echo "1. Проверка вложенных каталогов..."

find "$REPO" -mindepth 2 -type f -name '*.pkg' -print |
while IFS= read -r f; do
    relative=${f#"$REPO"/}
    move_aside "$f" "nested/$relative"
done

echo

# ---------- Проверка архивов в корне ----------

echo "2. Проверка пакетов в корне репозитория..."

VALID=0
INVALID=0

for f in "$REPO"/*.pkg; do

    [ -f "$f" ] || [ -L "$f" ] || continue

    base=${f##*/}

    # Индексы репозитория не являются пакетами.
    case "$base" in
        data.pkg|packagesite.pkg)
            continue
            ;;
    esac

    echo
    echo "Проверяется: $base"

    # Проверка полного манифеста.
    if ! bsdtar -xOf "$f" +MANIFEST 2>/dev/null |
        jq -e '
            type == "object"
            and ((.name // "") | type == "string" and length > 0)
            and ((.origin // "") | type == "string" and length > 0)
            and ((.version // "") | type == "string" and length > 0)
            and ((.desc // "") | tostring | gsub("[[:space:]]"; "") | length > 0)
        ' >/dev/null 2>&1
    then
        echo "[ОШИБКА] Отсутствует или повреждён +MANIFEST либо пустой desc"

        move_aside "$f" "invalid-root/$base"
        INVALID=$((INVALID + 1))
        continue
    fi

    # Проверка компактного манифеста.
    if ! bsdtar -xOf "$f" +COMPACT_MANIFEST 2>/dev/null |
        jq -e 'type == "object"' >/dev/null 2>&1
    then
        echo "[ОШИБКА] Отсутствует или повреждён +COMPACT_MANIFEST"

        move_aside "$f" "invalid-root/$base"
        INVALID=$((INVALID + 1))
        continue
    fi

    echo "[OK] Манифесты корректны"
    VALID=$((VALID + 1))
done

echo
echo "Корректных пакетов: $VALID"
echo "Перемещено в карантин: $INVALID"
echo

# ---------- Пересоздание индексов ----------

echo "3. Удаление старых индексов..."

rm -f "$REPO/data.pkg"
rm -f "$REPO/packagesite.pkg"

echo
echo "4. Создание нового индекса..."
echo

pkg repo "$REPO"

if [ ! -s "$REPO/data.pkg" ]; then
    echo "ОШИБКА: data.pkg не создан или пуст"
    exit 1
fi

echo
echo "5. Проверка нового data.pkg..."

# Проверка структуры индекса.
if ! bsdtar -xOf "$REPO/data.pkg" data |
    jq -e '.packages | type == "array"' >/dev/null 2>&1
then
    echo "ОШИБКА: data.pkg повреждён или имеет неправильную структуру"
    exit 1
fi

# ---------- Проверка пустых описаний ----------

EMPTY_COUNT=$(
    bsdtar -xOf "$REPO/data.pkg" data |
    jq '
        [
            .packages[]
            | select(
                ((.desc // "") | tostring | gsub("[[:space:]]"; "")) == ""
            )
        ]
        | length
    '
)

echo
echo "Пакетов с пустым desc: $EMPTY_COUNT"

if [ "$EMPTY_COUNT" -gt 0 ]; then
    echo
    echo "ПРОБЛЕМНЫЕ ЗАПИСИ:"
    bsdtar -xOf "$REPO/data.pkg" data |
    jq -r '
        .packages[]
        | select(
            ((.desc // "") | tostring | gsub("[[:space:]]"; "")) == ""
        )
        | [.name, .version, .origin, .path]
        | @tsv
    '

    echo
    echo "ОШИБКА: индекс содержит пакеты без desc."
    exit 1
fi

# ---------- Проверка дублей ----------

echo
echo "6. Проверка дублирующихся версий..."

DUP_COUNT=$(
    bsdtar -xOf "$REPO/data.pkg" data |
    jq '
        [
            .packages[]
            | {name, version, path}
        ]
        | group_by([.name, .version])
        | map(select(length > 1))
        | length
    '
)

if [ "$DUP_COUNT" -gt 0 ]; then
    echo "ОБНАРУЖЕНЫ ДУБЛИ:"

    bsdtar -xOf "$REPO/data.pkg" data |
    jq -r '
        [.packages[] | {name, version, path}]
        | group_by([.name, .version])
        | .[]
        | select(length > 1)
        | .[]
        | [.name, .version, .path]
        | @tsv
    '

    echo
    echo "ОШИБКА: необходимо устранить дубли."
    exit 1
fi

echo "Дубликатов одинаковых name/version нет."

# ---------- Итог ----------

echo
echo "=========================================="
echo " РЕПОЗИТОРИЙ УСПЕШНО ПРОВЕРЕН"
echo "=========================================="
echo "Корректных пакетов: $VALID"
echo "Пакетов в карантине: $INVALID"
echo "Пустых desc:        $EMPTY_COUNT"
echo "Дубликатов:         $DUP_COUNT"
echo
echo "Индекс: $REPO/data.pkg"
echo
echo "На клиенте выполни:"
echo "doas pkg update -f -r myrepo16"
echo
