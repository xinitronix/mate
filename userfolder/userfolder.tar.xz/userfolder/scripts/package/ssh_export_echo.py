from pathlib import Path
import textwrap
import subprocess
import getpass

SSH_DIR = Path.home() / ".ssh"
WRAP = 70


def wrap(text):
    return textwrap.wrap(text, WRAP)


def echo(line, file):
    return f"echo '{line}' >> {file}"


# ---------- CONFIG ----------
def generate_config():
    lines = []

    lines += [
        echo("Host pi", "config"),
        echo("HostName 192.168.8.45", "config"),
        echo("User pi", "config"),
        echo("", "config"),
    ]

    github_keys = [
        ("github.com", "id_ed25520"),
        ("github.com2", "id_ed25521"),
        ("github.com3", "id_ed25519"),
    ]

    for host, key in github_keys:
        if not (SSH_DIR / key).exists():
            continue

        lines += [
            echo(f"Host {host}", "config"),
            echo("HostName github.com", "config"),
            echo("User git", "config"),
            echo(f"IdentityFile ~/.ssh/{key}", "config"),
            echo("", "config"),
        ]

    return lines


# ---------- PRIVATE KEYS ----------
def generate_key(key_path: Path):
    lines = []
    content = key_path.read_text().strip()

    body = (
        content
        .replace("-----BEGIN OPENSSH PRIVATE KEY-----", "")
        .replace("-----END OPENSSH PRIVATE KEY-----", "")
        .replace("\n", "")
    )

    lines.append(echo("-----BEGIN OPENSSH PRIVATE KEY-----", key_path.name))
    for chunk in wrap(body):
        lines.append(echo(chunk, key_path.name))
    lines.append(echo("-----END OPENSSH PRIVATE KEY-----", key_path.name))

    return lines


# ---------- KNOWN_HOSTS ----------
def generate_known_hosts():
    lines = []
    kh = SSH_DIR / "known_hosts"

    if not kh.exists():
        return lines

    for line in kh.read_text().splitlines():
        if line.strip():
            lines.append(echo(line, "known_hosts"))

    return lines


# ---------- MAIN ----------
def main():
    # интерактивный ввод пароля
    ssh_passwd = getpass.getpass("Введите пароль для шифрования: ")

    commands = []

    commands.extend(generate_config())

    for key in ["id_ed25520", "id_ed25521", "id_ed25519", "id_rsa"]:
        kp = SSH_DIR / key
        if kp.exists():
            commands.extend(generate_key(kp))

    commands.extend(generate_known_hosts())

    for key in ["id_ed25520", "id_ed25521", "id_ed25519", "id_rsa"]:
        if (SSH_DIR / key).exists():
            commands.append(f"chmod 400 {key}")

    commands.append("chmod 600 config")
    commands.append("chmod 600 known_hosts")

    plaintext = "\n".join(commands).encode()

    # openssl encryption через stdin/stdout
    proc = subprocess.run(
        [
            "openssl", "enc",
            "-base64", "-e",
            "-aes-256-cbc",
            "-iter", "8",
            "-pass", f"pass:{ssh_passwd}",
        ],
        input=plaintext,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=True,
    )

    # вывод одной строки
    print(proc.stdout.decode().replace("\n", ""))


if __name__ == "__main__":
    main()
