#!/bin/sh
dir=$(dirname "$(realpath $0)")

if test "$(id -u)" -ne 0; then
	printf "%s run as user\n" "${0##*/}"
	

    for i in $(cat $dir/pkg_leaves_final); do

          doas pkg install  -r myrepo  -y  $i 

      done

else 

    for i in $(cat $dir/pkg_leaves_final); do

             pkg install  -r myrepo  -y  $i 

done


fi



