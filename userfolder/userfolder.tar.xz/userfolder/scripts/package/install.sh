#!/bin/sh

dir=$(dirname "$(realpath $0)")

 for i in $(cat $dir/pkg_leaves_final); do

pkg install  -r myrepo  -y  $i 
#pkg install  -r FreeBSD  -y $i 

   done
