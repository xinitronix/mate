#!/bin/sh


if test "$(id -u)" -ne 0; then
	printf "%s must be run as root\n" "${0##*/}"
	exit 1
fi


echo N |  pkg upgrade -r FreeBSD | grep - | sed -r 's/([^ ]*).*/\1/' | tr -d ":" >> /tmp/pkg_upgrade.txt



 for i in `cat /tmp/pkg_upgrade.txt` ; do 
    
  rm /ntfs-2TB/All/$i-*
  

done

pkg upgrade  -r  FreeBSD

for i in `cat /tmp/pkg_upgrade.txt` ; do 


line=$(uname -r | grep 15)

if [ -z "$line" ]
then
     sshpass -p 639639 ssh pi@192.168.8.45 "rm ~/All16/$i-*"
else
   sshpass -p 639639 ssh pi@192.168.8.45 "rm ~/All15/$i-*"
fi


         


  done 

#cat pkg_upgrade.txt  | grep - | rev | sed -r 's/^[^-]+//' | rev |  sed -r 's/([^ ]*).*/\1/' | tr -d "-"  