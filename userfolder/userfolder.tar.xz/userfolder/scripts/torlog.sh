#!/bin/sh

sshpass -p 639639 ssh vcore@192.168.8.106 "echo 639639 | sudo -S cat /var/log/tor/notices.log" 