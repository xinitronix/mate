#!/bin/sh
login=$(whoami)
mkdir  ~/.mozilla
rm -r ~/.mozilla/firefox
doas cp -R "/ntfs-2TB/freebsd config/firefox" ~/.mozilla
doas chown -R $login:wheel ~/.mozilla
