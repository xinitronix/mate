#!/bin/sh

if test "$(id -u)" -ne 0; then
	printf "%s must be run as root\n" "${0##*/}"
	exit 1
fi


mkdir -p /etc/v2raya/
touch  /etc/v2raya/boltv4.db
mkdir -p /usr/local/share/v2ray
cd /usr/local/share/v2ray
fetch https://github.com/runetfreedom/russia-v2ray-rules-dat/releases/download/202507102142/geoip.dat
fetch https://github.com/runetfreedom/russia-v2ray-rules-dat/releases/download/202507102142/geosite.dat