#!/bin/sh

if [ -z "$1" ]
then
     echo "не задана директория где находится папака firefox"
     exit
fi

cd "$1"
XZ_OPT=-9 tar cJf  $HOME/firefox.tar.xz  firefox 
openssl enc -aes-256-cbc -pbkdf2 -iter 100000 -e  -in  $HOME/firefox.tar.xz  -out $HOME/firefox.tar.xz.enc
cd -