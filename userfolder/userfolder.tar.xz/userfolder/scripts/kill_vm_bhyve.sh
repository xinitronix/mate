#!/bin/sh

for i in $(ls /dev/vmm ); do

           doas bhyvectl --destroy --vm=$i
           doas kldunload vmm
      done